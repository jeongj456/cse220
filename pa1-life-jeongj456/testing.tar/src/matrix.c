#include <stdbool.h>

bool verify_matrix(int x, int y, int **matrix) {
    int previous=matrix[0][0];
    int pfc = matrix[0][0];
    int ty=0;
    int tx=0;
    for(ty=0;ty<y; ty++){
        for(tx=0; tx<x; tx++){
            if(matrix[ty][tx]>=previous){
                previous=matrix[ty][tx];
            }else{
                return false;
            }
       }
        if(ty+1<y){
          previous=matrix[ty+1][0];  
        }
    }
    for(int i=0;i<ty; i++){
        if(matrix[i][0]>=pfc){
            pfc=matrix[i][0];
        }else{
            return false;
        }
    }
    if(ty!=tx){
        return false;
    }
    return true;
}


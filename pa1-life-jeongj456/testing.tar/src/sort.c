#include <stdbool.h>

#include "sort.h"

void cse_sort(int array[]);

bool test_sort() {
    int testarray0[] = { 1,2,3, 0 };
    cse_sort(testarray0);
    for(int i=1; testarray0[i]!=0; i++){
        if (testarray0[i]<testarray0[i-1]){
            return false;
        }
    }

    int testarray1[] = { 45, 44,43,40, 0 };
    cse_sort(testarray1);
    for(int i=1; testarray1[i]!=0; i++){
        if (testarray1[i]<testarray1[i-1]){
            return false;
        }
    }

    int testarray2[] = { 0 };
    cse_sort(testarray2);
    for(int i=1; testarray2[i]!=0; i++){
        if (testarray2[i]<testarray2[i-1]){
            return false;
        }
    }

    int testarray3[] = { 3000000, 200000, 10000000, 0 };
    cse_sort(testarray3);
    for(int i=1; testarray3[i]!=0; i++){
        if (testarray3[i]<testarray3[i-1]){
            return false;
        }
    }

    int testarray5[]={20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1, 0};
    cse_sort(testarray5);
    for(int i=1; testarray5[i]!=0; i++){
        if (testarray5[i]<testarray5[i-1]){
            return false;
        }
    }


    int testarray6[]={1,1,1,1,1,1,1,1,1,1,0};
    cse_sort(testarray6);
    for(int i=1; testarray6[i]!=0; i++){
        if (testarray6[i]<testarray6[i-1]){
            return false;
        }
    }

    int testarray7[]={1,-1,1,1,1,-1,1,1,-1,1,0};
    cse_sort(testarray7);
    for(int i=1; testarray7[i]!=0; i++){
        if (testarray7[i]<testarray7[i-1]){
            return false;
        }
    }



    return true;
}
